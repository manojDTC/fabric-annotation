import "./App.css";
import Annotations from "./Annotations";

function App() {
  return (
    <div className="App">
      <Annotations />
    </div>
  );
}

export default App;
