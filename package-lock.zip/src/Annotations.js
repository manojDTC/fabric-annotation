import { useState, useEffect } from "react";

function App() {
  useEffect(() => {
    //console.log("hi");
  }, []);
  return (
    <div className="App">
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div>
          <div className="controls">
            <button
            // onClick={enableSelectTool()}
            >
              Select
            </button>
            <button
              id="add"
              // onClick={enableRectangleDrawing()}
            >
              Rect
            </button>
            <button
              id="add"
              // onClick={addPolygon()}
            >
              Polygon
            </button>
            <button
              id="panButton"
              // onClick={enablePanning()}
            >
              pan
            </button>
            <button
              id="zoomInBtn"
              // onClick={zoomIn()}
            >
              Zoom In
            </button>
            <button
              id="zoomOutBtn"
              // onClick={zoomOut()}
            >
              zoom out
            </button>
            <button
              id="resetButton"
              // onClick={resetZoom()}
            >
              Reset
            </button>
          </div>
          <div className="crosshair-div">
            <div id="crosshair-h" className="hair"></div>
            <div id="crosshair-v" className="hair"></div>
            <canvas id="canvas" width="800" height="500"></canvas>
          </div>
        </div>

        <div className="annotation-editor">
          <h2>Annotation Editor</h2>
          <select
            name="labels"
            id="labels"
            value="label 1"
            onChange={() => {
              console.log("hi");
            }}
          >
            <option value="" disabled selected>
              Select Label
            </option>
          </select>
          <br />
          <br />
          <div className="submit">
            <button
              className="save"
              // onClick={saveAnnotation()}
            >
              Save
            </button>
            <button
              id="deleteBtn"
              //   onClick={deleteAnnotation()}
              className="delete"
            >
              delete
            </button>
          </div>
        </div>
        <div style={{ position: "absolute", top: "50px", right: "10px" }}>
          <ul
            id="selectedItems"
            //   onSelect={backgroundColorChange()}
          ></ul>
        </div>
      </div>
    </div>
  );
}

export default App;
